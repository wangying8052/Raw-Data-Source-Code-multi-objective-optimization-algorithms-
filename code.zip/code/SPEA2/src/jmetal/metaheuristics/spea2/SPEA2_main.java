/**
 * SPEA2_main.java
 *
 * @author Juan J. Durillo
 * @version 1.0
 */
package jmetal.metaheuristics.spea2;

import java.io.IOException;
import jmetal.base.*;
import jmetal.base.operator.crossover.*   ;
import jmetal.base.operator.mutation.*    ; 
import jmetal.base.operator.selection.*   ;
import jmetal.problems.*                  ;

import jmetal.util.JMException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

public class SPEA2_main {
  public static Logger      logger_ ;      // Logger object
  public static FileHandler fileHandler_ ; // FileHandler object
  
  /**
   * @param args Command line arguments. The first (optional) argument specifies 
   *             the problem to solve.
   * @throws JMException 
   */
  public static void main(String [] args) throws JMException, IOException {
    Problem   problem   ;         // The problem to solve
    Algorithm algorithm ;         // The algorithm to use
    Operator  crossover ;         // Crossover operator
    Operator  mutation  ;         // Mutation operator
    Operator  selection ;         // Selection operator
        
    // Logger object and file to store log messages
    logger_      = Configuration.logger_ ;
    fileHandler_ = new FileHandler("SPEA2.log"); 
    logger_.addHandler(fileHandler_) ;
    
      problem=new OrderAM("Permutation");
     // problem=new OrderPR("Permutation");
    
    algorithm = new SPEA2(problem);
    
    //ANT,BCEL,DNS,xml,joda-time,jmeter
    int populationSize=300;
    int archiveSize=250;
    int maxEvaluations=60000;
    double crossoverprobability=0.95;
    double mutationprobability=0.02;
    double distributionIndex=20.0;
    
    // Algorithm params    
    algorithm.setInputParameter("populationSize",populationSize);
    algorithm.setInputParameter("archiveSize",archiveSize);
    algorithm.setInputParameter("maxEvaluations",maxEvaluations);
      
    // Mutation and Crossover for Real codification
    crossover = CrossoverFactory.getCrossoverOperator("PMXCrossover");                   
    crossover.setParameter("probability",crossoverprobability);                   
    crossover.setParameter("distribuitionIndex",distributionIndex);
    mutation = MutationFactory.getMutationOperator("SwapMutation");                    
    mutation.setParameter("probability",mutationprobability);
    mutation.setParameter("distributionIndex",distributionIndex);
    
    
    /* Mutation and Crossover Binary codification */
    /*
    crossover = CrossoverFactory.getCrossoverOperator("SinglePointCrossover");                   
    crossover.setParameter("probability",0.9);                   
    mutation = MutationFactory.getMutationOperator("BitFlipMutation");                    
    mutation.setParameter("probability",1.0/80);
    */
    
    /* Selection Operator */
    selection = SelectionFactory.getSelectionOperator("BinaryTournament") ;                           
    
    // Add the operators to the algorithm
    algorithm.addOperator("crossover",crossover);
    algorithm.addOperator("mutation",mutation);
    algorithm.addOperator("selection",selection);
    
    // Execute the Algorithm
    long initTime = System.currentTimeMillis();
    SolutionSet population = algorithm.execute();
    long estimatedTime = System.currentTimeMillis() - initTime;

    population.printVariables();
    System.out.println(estimatedTime*0.001+"s");
    
       // Result messages 
    /*logger_.info("Total execution time: "+estimatedTime);
    logger_.info("Objectives values have been writen to file FUN");
    population.printObjectivesToFile("FUN");
    logger_.info("Variables values have been writen to file VAR");
    population.printVariablesToFile("VAR");      */
  }//main
} // SPEA2_main.java
