package jmetal.problems;

import jmetal.base.DecisionVariables;
import jmetal.base.Problem;
import jmetal.base.Solution;
import jmetal.base.Configuration.SolutionType_;
import jmetal.base.Configuration.VariableType_;
import jmetal.util.JMException;
import jmetal.base.OrderWeight;

public class OrderPR extends Problem {

	public OrderPR(String solutionType){
		this(1,solutionType);
	}
	public OrderPR(Integer numberOfVariables,String solutionType){
	    numberOfVariables_  = numberOfVariables.intValue();
        numberOfObjectives_=3;
        numberOfConstraints_=0;     	
	    problemName_="OrderPR";
	    solutionType_ = Enum.valueOf(SolutionType_.class, solutionType) ; 
        variableType_ = new VariableType_[numberOfVariables_] ;
        length_ = new int[numberOfVariables_];
        for (int var = 0; var < numberOfVariables_; var++) {
            variableType_[var] = Enum.valueOf(VariableType_.class, solutionType) ;
            length_[var]=A.length;
        }

	}

	jmetal.qualityIndicator.util.MetricsUtil utilities_ =new jmetal.qualityIndicator.util.MetricsUtil() ;
	 double[][] A = utilities_.readFront("xmlAM.txt");
	 double[][] M = utilities_.readFront("xmlMM.txt");
	 //double[][] D = utilities_.readFront("xmlDM.txt");
	 double[][] W = utilities_.readFront("xml_R.TXT");
	 
	 //static int n=0;

	 
	@Override
	public void evaluate(Solution solution) throws JMException {
		// TODO Auto-generated method stub
	     
		// n++;
		 
		 DecisionVariables gen  = solution.getDecisionVariables();
		 String []s=gen.variables_[0].toString().split(" ");
		 int size=A.length;
		 int []order=new int[size];
		 for (int i = 0; i < size; i++) {
	        	order[i]=Integer.parseInt(s[i]);
	        }
		 
		 int a=0,m=0;
	     double aa,mm;
		 for(int i=0;i<size;i++){
				for(int j=0;j<size;j++){
					if(order[i]==j){
						for(int k=0;k<size;k++){
	        				if(A[j][k]!=0||M[j][k]!=0){	
							//if(D[j][k]!=0){
	        					aa=A[j][k];
	        					mm=M[j][k];
	        					for(int n=0;n<i;n++){
	        						if(order[n]==k){
	            						aa=0;
	            						mm=0;
	            					}//if
	        					}//for
								a+=aa;
								m+=mm;
	        				}
						}
					}
				}
			}
		 
		 
			OrderWeight []ow=new OrderWeight[A.length];
			OrderWeight []ow1=new OrderWeight[A.length];
			for (int i = 0; i < ow.length; i++) {
				ow[i]=new OrderWeight(order[i],W[order[i]][0]);
				ow1[i]=new OrderWeight(order[i],W[order[i]][0]);
			}
			
			OrderWeight flag;
			for (int i = 0; i < ow.length-1; i++) {
				for (int j = i+1; j < ow.length; j++) {
					if(ow1[i].weight<ow1[j].weight){
						flag=ow1[i];
						ow1[i]=ow1[j];
						ow1[j]=flag;
					}
				}
			}
			
			
			double sum1=0;
			for (int i = 0; i < ow.length; i++) 
				sum1+=2*(ow.length-i-1+1)*ow1[i].weight;
			sum1/=(ow.length*(ow.length+1));
			
			
			
			double sum2=0,PR=0,pr;
			for (int i = 0; i < ow.length; i++) 
				sum2+=2*(ow.length-i-1+1)*ow[i].weight;
				
			sum2/=(ow.length*(ow.length+1));

			
			PR=sum2/sum1;
			pr=1-PR;
	        solution.setObjective(0,a);
	        solution.setObjective(1,m);
	        solution.setObjective(2,pr);
			}
		
	}


