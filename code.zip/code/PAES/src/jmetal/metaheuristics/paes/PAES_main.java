/*
 * Main.java
 *
 * @author Juanjo Durillo
 * @version 1.0
 */
package jmetal.metaheuristics.paes;

import java.io.IOException;
import jmetal.base.*                      ;
import jmetal.base.operator.mutation.*    ; 
import jmetal.problems.*                  ;
import jmetal.util.JMException;

import java.util.logging.FileHandler;
import java.util.logging.Logger;
import jmetal.qualityIndicator.QualityIndicator;

public class PAES_main {
  public static Logger      logger_ ;      // Logger object
  public static FileHandler fileHandler_ ; // FileHandler object

  /**
   * @param args Command line arguments. The first (optional) argument specifies 
   *             the problem to solve.
   * @throws JMException 
   */
  public static void main(String [] args) throws JMException, IOException {
    Problem   problem   ;         // The problem to solve
    Algorithm algorithm ;         // The algorithm to use
    Operator  crossover ;         // Crossover operator
    Operator  mutation  ;         // Mutation operator
    Operator  selection ;         // Selection operator
    
    //QualityIndicator indicators ; // Object to get quality indicators

    // Logger object and file to store log messages
    logger_      = Configuration.logger_ ;
    fileHandler_ = new FileHandler("PAES_main.log");
    logger_.addHandler(fileHandler_) ;
    
    //indicators = null ;
    problem=new OrderAM("Permutation");
    //problem=new OrderPR("Permutation");
  
    algorithm = new PAES(problem);
    
    //ANT
    int archiveSize=250;
    int biSections=2;
    int maxEvaluations=60000;
    
    //BCEL,DNS,joda-time
    /*int archiveSize=250;
    int biSections=2;
    int maxEvaluations=100000;*/
    
    //joda-time
    /* int archiveSize=250;
     int biSections=2;
     int maxEvaluations=100000;*/
     
     //jmeter
     /*int archiveSize=200;
     int biSections=2;
     int maxEvaluations=100000;*/
     
    double mutationprobability=1.0;
    double distributionIndex=20.0;
    
    // Algorithm parameters
    algorithm.setInputParameter("archiveSize",archiveSize);//archiveSiZe~populationSize
    algorithm.setInputParameter("biSections",biSections);/*The maximum number of bi-divisions for the adaptivegrid.*/
    algorithm.setInputParameter("maxEvaluations",maxEvaluations);
      
    // Mutation 
    mutation = MutationFactory.getMutationOperator("SwapMutation");                    
    mutation.setParameter("probability",mutationprobability);
    mutation.setParameter("distributionIndex",distributionIndex);
    
    // Mutation (BinaryReal variables)
    //mutation = MutationFactory.getMutationOperator("BitFlipMutation");                    
    //mutation.setParameter("probability",1.0/80);
    
    // Add the operators to the algorithm
    algorithm.addOperator("mutation", mutation);
    
    // Execute the Algorithm 
    long initTime = System.currentTimeMillis();
    SolutionSet population = algorithm.execute();
    long estimatedTime = System.currentTimeMillis() - initTime;
    
    population. printVariables();
    System.out.println(estimatedTime*0.001+"s");
    // Result messages 
    /*logger_.info("Total execution time: "+estimatedTime);
    logger_.info("Objectives values have been writen to file FUN");
    population.printObjectivesToFile("FUN");
    logger_.info("Variables values have been writen to file VAR");
    population.printVariablesToFile("VAR"); */           
  }//main
}
