package jmetal.base;

public class OrderWeight {
	int vaule;
	public double weight;
	public OrderWeight() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OrderWeight(int vaule, double weight) {
		super();
		this.vaule = vaule;
		this.weight = weight;
	}
	public int getVaule() {
		return vaule;
	}
	public void setVaule(int vaule) {
		this.vaule = vaule;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	
	
	

}
