package jmetal.base;

public class OrderWF {
	int value;
	double weight;
	int fault;
	
	public OrderWF() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderWF(int value, double weight, int fault) {
		super();
		this.value = value;
		this.weight = weight;
		this.fault = fault;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public int getFault() {
		return fault;
	}

	public void setFault(int fault) {
		this.fault = fault;
	}
	

}
