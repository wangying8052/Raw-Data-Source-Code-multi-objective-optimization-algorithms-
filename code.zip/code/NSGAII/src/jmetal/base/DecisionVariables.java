/**
 * DecisionVariables.java
 * 
 * @author Juan J. durillo
 * @version 1.0 
 */
package jmetal.base;

import java.io.Serializable;

import jmetal.base.Configuration.* ;
import jmetal.base.variable.Permutation;


/** 
 * This class contains the decision variables of a solution
 */
public class DecisionVariables implements Serializable {  
  /**
   * Stores the decision variables of a solution
   */
  public Variable [] variables_;
  
  /**
   * The problem to solve
   */
  private Problem problem_;
  
  /**
   * Constructor
   * @param problem The problem to solve
   */
  public DecisionVariables(Problem problem){
    problem_   = problem;
    variables_ = new Variable[problem_.getNumberOfVariables()];

     if (problem.solutionType_ == SolutionType_.Permutation) {
      for (int var = 0; var < problem_.getNumberOfVariables(); var++)
        variables_[var] = new Permutation(problem_.getLength(var)) ;   
    } 
    else {
      Configuration.logger_.severe("DecisionVariables.DecisionVariables: " +
          "the solutio type " + problem.solutionType_ + " is incorrect") ;
      //System.exit(-1) ;
    } // else
  } // DecisionVariable
   
  /**
   * Copy constructor
   * @param decisionVariables The <code>DecisionVariables<code> object to copy.
   */
  public DecisionVariables(DecisionVariables decisionVariables){
    problem_ = decisionVariables.problem_;
    variables_ = new Variable[decisionVariables.variables_.length];
    for (int var = 0; var < decisionVariables.variables_.length; var++) {
      variables_[var] = decisionVariables.variables_[var].deepCopy();
    }
  } // DecisionVariable
    
  /**
   * Returns the number of decision variables.
   * @return The number of decision variables.
   */
  public int size(){
    return problem_.getNumberOfVariables();
  } // size

    
  /** Returns a String that represent the DecisionVariable
   * @return The string.
   */
  public String toString() {
    String aux = "";
    for (int i = 0; i < variables_.length; i++) {
      if(i==0){
    	  aux+=variables_[i].toString();
      }
      if(i!=0){
      aux+= " "+variables_[i].toString();
    	}
    }
    return aux;
  } // toString
} // DecisionVariables
