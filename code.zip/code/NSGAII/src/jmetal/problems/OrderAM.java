package jmetal.problems;

import jmetal.base.DecisionVariables;
import jmetal.base.Problem;
import jmetal.base.Solution;
import jmetal.base.Configuration.SolutionType_;
import jmetal.base.Configuration.VariableType_;
import jmetal.util.JMException;

public class OrderAM extends Problem {

	
	 
	public OrderAM(String solutionType){
		this(1,solutionType);
	}
	public OrderAM(Integer numberOfVariables,String solutionType){
	    numberOfVariables_  = numberOfVariables.intValue();
        numberOfObjectives_=2;
        numberOfConstraints_=0;     	
	    problemName_="OrderAnt";
	    solutionType_ = Enum.valueOf(SolutionType_.class, solutionType) ; 
        variableType_ = new VariableType_[numberOfVariables_] ;
        length_ = new int[numberOfVariables_];
        for (int var = 0; var < numberOfVariables_; var++) {
            variableType_[var] = Enum.valueOf(VariableType_.class, solutionType) ;
            length_[var]=A.length;
        }
	}

	
	jmetal.qualityIndicator.util.MetricsUtil utilities_ =new jmetal.qualityIndicator.util.MetricsUtil() ;
	 double[][] A = utilities_.readFront("antAM.txt");
	 double[][] M = utilities_.readFront("antMM.txt");
	 double[][] D = utilities_.readFront("antDM.txt");
	 //static int n=0;

	@Override
	public void evaluate(Solution solution) throws JMException {
		// TODO Auto-generated method stub
	     
		// n++;
		 
		 DecisionVariables gen  = solution.getDecisionVariables();
		 String []s=gen.variables_[0].toString().split(" ");
		 int size=A.length;
		 int []order=new int[size];
		 for (int i = 0; i < size; i++) {
	        	order[i]=Integer.parseInt(s[i]);
	        }
		 
	     int a=0,m=0;
	     double aa,mm;
		 for(int i=0;i<size;i++){
				for(int j=0;j<size;j++){
					if(order[i]==j){
						for(int k=0;k<size;k++){
	        				//if(A[j][k]!=0||M[j][k]!=0){	
							if(D[j][k]!=0){
	        					aa=A[j][k];
	        					mm=M[j][k];
	        					for(int n=0;n<i;n++){
	        						if(order[n]==k){
	            						aa=0;
	            						mm=0;
	            					}//if
	        					}//for
								a+=aa;
								m+=mm;
	        				}
						}
					}
				}
			}
		
	        solution.setObjective(0,a);
	        solution.setObjective(1,m);
			}
		
	}


